WhatsApp Auth Clone Android Client
=================================

This is the second part of the [How to Implement a Mechanism like QR code scanning of WhatsApp Web Tutorial](http://blog.jbaysolutions.com/2016/09/20/how-to-implement-a-mechanism-like-qr-code-scanning-of-whatsapp-web/)

The first part of the Tutorial can be found here : [WhatsApp Auth Clone using Play2 - Server](https://github.com/jbaysolutions/whatsapp-clone-play-server)


To Do to Use this Program
===========

- Firebase Cloud Messaging - Register on the Firebase console the App and replace the file `google-services.json` with the one provided on the Firebase Console.
